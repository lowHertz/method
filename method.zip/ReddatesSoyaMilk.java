
public class ReddatesSoyaMilk extends SoyaMilkWithHook {
	
	void addCondiments() {
		System.out.println("add bean");
	}

}


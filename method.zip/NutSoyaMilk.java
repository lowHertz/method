
public class NutSoyaMilk extends SoyaMilkWithHook {
	
	
	void addCondiments() {
		System.out.println("add Nuts");
	}
	
	
}

